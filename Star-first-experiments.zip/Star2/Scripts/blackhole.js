var camera, controls, scene, renderer, container;

var PI = Math.PI;
var clock = new THREE.Clock(); 
var delta = 0;

var total_mass = 0;
var maximum_mass = 0.00;

var mov_alive_count = 0;
var mov = [];
var step = 0;

var options = {
	NAME:"GENERAL",
	version:0, 
    framerate: 50,
  //  G: 20,
	
    START_SPEED: 20,
    MOVER_COUNT: 32,
	
    TRAILS_DISPLAY: true,
    SHOW_DIED: false,
    SHOW_LABELS: true, 
    TRAILS_LENGTH: 1000,
	
    MIN_MASS: 0.01,
    MAX_MASS: 1000,
    
	DENSITY: 0.1,

    MoveSpeed: 500,
    MAX_DISTANCE: 100000,
    BIG_STAR_MASS:2000000,
	
//	MASS_FACTOR : .01 // for display of size
};

var MASS_FACTOR = 0.01;




function init() {

	renderer = new THREE.WebGLRenderer( { antialias: true, alpha: true} );
	renderer.setPixelRatio( window.devicePixelRatio ); 
	renderer.shadowMap.enabled = true; 
	renderer.shadowMap.type = THREE.PCFSoftShadowMap;
	//renderer.sortObjects = true;
	         
	container = document.getElementById('container');
	renderer.setSize(container.clientWidth, container.clientHeight);
	container.appendChild( renderer.domElement );

	var aspect = container.clientWidth / container.clientHeight; 
	scene = new THREE.Scene();
	scene.background = new THREE.Color( 0x000000 );
	
	camera = new THREE.PerspectiveCamera( 60, container.clientWidth / container.clientHeight, 1, 100000000 );
	camera.position.set(5000, 0, 0);
//	camera.lookAt(new THREE.Vector3(0,0,0));

controls = new THREE.OrbitControls( camera, renderer.domElement );
controls.enableZoom = true;
controls.enabled = true;
//controls.target.set(0, 0, 0);
//camera.up = new THREE.Vector3(0, 0, 1);
//controls.update();

controls.minDistance = 600;
controls.maxDistance = 1000000;

//-------------------------------------------------

for (var i = 0; i < 18; i++) {
    AddRandomMov(i);
}

AddBigMoverToCent();

//-------------------------------------------------

var light = new THREE.AmbientLight(0xffffff, 0.2); // soft white light
scene.add(light);
  

var light = new THREE.PointLight( 0xffffff, 1.5, 100000 ); 
light.position.set( 0, 0, 0 ); 
light.castShadow = true; // default false 
scene.add( light );
  
  
var light2 = new THREE.PointLight( 0xff0000, 100, 100000 ); 
light2.position.set( -2000, 0, 0 ); 
//scene.add( light2 );
  
}


var now;
var then = Date.now();
var renderInterval = 1000 / parseInt(options.framerate);
var renderDelta;


function animate() {

    requestAnimationFrame( animate );  
    now = Date.now();
    renderDelta = now - then;
    if (renderDelta > renderInterval) {
        then = now - (renderDelta % renderInterval);
        render();
    }	
//render();
}

var pause = false;



function render() {
   
         
        
//------       
       
    if (mov && mov.length) {
      
            // FIRST LOOP 
            for (var i = mov.length - 1; i >= 0; i--) {
                var m = mov[i];

                if (m.exists) {
                    mov_alive_count++;
                    total_mass += m.mass;
                    if (m.mass > maximum_mass) {
                        maximum_mass = m.mass;
                    }

                    // SECOND LOOP 
                    //-----------
                                        
                    for (var j = mov.length - 1; j >= 0; j--) {
                        var a = mov[j];
                        
                        if (mov[i].exists && mov[j].exists && i != j) { 
                        
                            var distance = m.position.distanceTo(a.position);							
                            var radiusM = 300;
                            var radiusA = 100;
                        
                            if (distance < radiusM + radiusA) {
                                // merge objects
                                if (a.mass > m.mass)
                                    a.eat(m);
                                else
                                    m.eat(a);
                            } else {
                                a.gravity(m);  
                            }
                                               
                        }                  
                    }                                          
               }                                                                     
          }
     }

//------

//------
var dt = clock.getDelta();

        for (var i = mov.length -1; i >= 0; i--) {
        var m = mov[i];
            if (m.exists) {
                    m.update(); 
                    if(i<mov.length-1){            
                    m.starupdate();
                    m.Trajectory();
                    }
                    if(i===mov.length-1){  
                    
            //        m.GlowSize(500, 5000, 400, camera.position);
                    m.blackholeupdate(dt);   
                    //m.particleemitter();
                  
                    }             
            }                
        }
        

        
//------       

controls.target.set(mov[mov.length-1].position.x, 
mov[mov.length-1].position.y, mov[mov.length-1].position.z
);




controls.update();
camera.up = new THREE.Vector3(0, 1, 0);
camera.updateMatrixWorld();
camera.updateProjectionMatrix(); 
renderer.render(scene, camera); 
	
}


//**********************************************************

function random(min, max) {
    return Math.random() * (max - min) + min;
}


function addToMov(mv) {
        mov.push(mv);
    }
    
    function random(min, max) {
    return Math.random() * (max - min) + min;
}

function AddRandomMov(id) {

    var mass = random(options.MIN_MASS, options.MAX_MASS);

    var max_distance = parseFloat(1000 / options.DENSITY);
    var max_speed = parseFloat(options.START_SPEED);

    var vel = new THREE.Vector3(
        random(-max_speed, max_speed),
        random(-max_speed, max_speed),
        random(-max_speed, max_speed));

    var pos = new THREE.Vector3(
        random(-max_distance, max_distance),
        random(-max_distance, max_distance),
        random(-max_distance, max_distance));

       var newMov = new Star(pos, vel, mass, id);
       addToMov(newMov);
}

function AddBigMoverToCent() {
	var mass = options.BIG_STAR_MASS;

	var vel = new THREE.Vector3(0,0,0);
	var pos = new THREE.Vector3(0,0,0);
	
	big = new Blackhole(pos, vel, mass, mov.length);
	addToMov(big);
	
}