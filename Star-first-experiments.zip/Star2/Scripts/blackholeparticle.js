const G = 2.5;

var phi = 0;
var theta = 0;
var radius = 500;

class Kinematic {

constructor(pos, vel, m){   
this.position = pos;
this.velocity = vel;
this.acceleration = new THREE.Vector3(0, 0, 0);
this.mass = m;

}//end constructor

gravity(M) {// M is the other mass
//vektor between m and M
var a = new THREE.Vector3().subVectors(this.position, M.position);
var d = a.length();//distance between m and M
a = a.normalize();//direction of acceleration
var magnitude = G*M.mass/Math.pow(d, 2);//magnitude of acceleration
a = a.multiplyScalar(-magnitude);//complete vektor of acceleration
this.acceleration.add(a);
}//end gravity

update() {
//acceleration initialized by "gravity()"
//first calculate velocity with acceleration
//then calculate position with velocity
this.velocity.add(this.acceleration);
this.position.add(this.velocity);
this.acceleration.multiplyScalar(0);   //reset acceleration for next loop
}//end update

}//end Kinematic
    


class Star extends Kinematic {

constructor(pos, vel, m, index){
super(pos, vel, m);
this.index = index;
this.exists = true;

this.vertices = [];
this.trajectory = new THREE.Line();
this.buffergeometry = new THREE.BufferGeometry();


this.geometry = new THREE.SphereBufferGeometry(100, 32, 32);
this.basicMaterial = new THREE.MeshPhongMaterial({
        color: 0xffffff,
});

this.mesh = new THREE.Mesh(this.geometry, this.basicMaterial);
scene.add(this.mesh);



this.coronaVertexShader = `
attribute float alpha;
attribute float opacity;
varying vec3 vNormal;
varying float vOpacity;
varying float vAlpha;
void main() { 	
vAlpha = alpha;
vOpacity = opacity;
vNormal = normalize( normalMatrix * normal );
vec4 modelViewPosition = modelViewMatrix * vec4(position, 1.0);
gl_Position = projectionMatrix * modelViewPosition; 	
}`;

this.coronaFragmentShader = `
varying float vAlpha;
varying float vOpacity;
varying vec3 vNormal;
void main() { 	
float intensity = pow( 0.5 - dot( vNormal, vec3( 0.0, 0.0, 1.0 ) ), 5.0 );
float opacity = pow( 0.1 - dot( vNormal, vec3( 0.0, 0.0, 1.0 ) ), 0.6 );
float alpha = pow( 0.0 - dot( vNormal, vec3( 0.0, 0.0, 1.0 ) ), 1.0 );
gl_FragColor = vec4(1.0, 0.9, 0.5, opacity) * intensity; 
}`;

this.CoronaShader = new THREE.ShaderMaterial( {					
  //uniforms: unif,					
  vertexShader: this.coronaVertexShader,
  fragmentShader: this.coronaFragmentShader,
  side: THREE.BackSide,
  //side: THREE.DoubleSide,
  //blending: THREE.AdditiveBlending,
  transparent: true
}); 



this.lineVertexShader = `  
   uniform float amplitude;
   attribute float opacity;
   attribute vec3 customColor;
   varying vec3 vColor;
   varying float vOpacity;
   
   void main() {				
   vec3 newPosition = position;	
   vOpacity = opacity;
   vColor = customColor;				
   gl_Position = projectionMatrix * modelViewMatrix * vec4( newPosition, 1.0 );			
}`;
		    
this.lineFragmentShader = `  
   uniform vec3 color;
   varying vec3 vColor;
   varying float vOpacity;

   void main() {				
   gl_FragColor = vec4( color , vOpacity);			
}`;
 
this.uniforms = {					
   amplitude: { value: 1.0 },					
   opacity: { value: 1 },					
   color: { value: new THREE.Color( 0x00ff00 ) }				
};				
		
this.shader = new THREE.ShaderMaterial( {					
 			uniforms: this.uniforms,					
       vertexShader: this.lineVertexShader,
       fragmentShader: this.lineFragmentShader,
   	//	blending: THREE.AdditiveBlending,		
   		linewidth: 1,
 		//	depthTest: false,					
 			transparent: true				
}); 


this.Trajectory();
this.trajectory = new THREE.Line( this.buffergeometry, this.shader ); 
this.trajectory.frustumCulled = false; 
scene.add(this.trajectory);     

    
    
}//end constructor


Trajectory() {
      
    this.positions = new Float32Array( this.vertices.length * 3 ); 
    this.opacitys = new Float32Array( this.vertices.length * 3 );     
    this.buffergeometry.addAttribute( 'position', new THREE.BufferAttribute( this.positions, 3 ).copyVector3sArray( this.vertices ) );		
            
    for( var i = 0; i <= this.vertices.length; i++ ) {  
        this.opacitys[this.vertices.length-i] = (1-Math.pow(i/this.vertices.length, 0.33) );     
    }
    this.buffergeometry.addAttribute( 'opacity', new THREE.BufferAttribute( this.opacitys, 1 ) );
}


starupdate(){
this.update();

this.mesh.position.copy(this.position);

if (this.vertices.length > 500) {
this.vertices.splice(0, 1);
}
this.vertices.push(this.position.clone());
}


//------

eat(M) { // M is the other mass

   var newMass = this.mass + M.mass;

   var newPosition = new THREE.Vector3((
   this.position.multiplyScalar(this.mass) + M.position.multiplyScalar(M.mass))/newMass);
   var newVelocity = new THREE.Vector3((
   this.velocity.multiplyScalar(this.mass) + M.velocity.multiplyScalar(M.mass))/newMass);

   this.position = newPosition;
   this.velocity = newVelocity;
   this.mass = newMass;

M.kill();
      
}

kill() {
   this.exists = false;
   scene.remove(this.mesh);
   scene.remove(this.trajectory);
}



//------

}//end Star








var counts = 20;
var counts2 = 100;

class Blackhole extends Kinematic {

constructor(pos, vel, m, index){
super(pos, vel, m);
this.index = index;
this.exists = true;
this.particles = [];

this.emittergroup = new THREE.Group();
this.emittergroup2 = new THREE.Group();
this.proton = new Proton(); 
this.emitter = [];
this.emitter2 = [];
//--------

//--------

for(var i = 0; i < counts; i++){
this.emitter[i] = new Proton.Emitter(); 

this.emitter[i].rate = new Proton.Rate(new Proton.Span(1, 1), new Proton.Span(0.1, 0.25)); 

//addInitialize 
this.emitter[i].addInitialize(new Proton.Position(new Proton.PointZone(0, 0, 0))); this.emitter[i].addInitialize(new Proton.Mass(1)); 
this.emitter[i].addInitialize(new Proton.Radius(300, 300)); //particelgrösse
this.emitter[i].addInitialize(new Proton.Life(9)); 
this.emitter[i].addInitialize(new Proton.V(0, new Proton.Vector3D(
Math.random()+0.5, 
Math.random()+0.5, 
Math.random()+0.5
), 36)); 
this.emitter[i].addInitialize(new Proton.Body( createSnow() ));

//addBehaviour 
this.emitter[i].addBehaviour(new Proton.Alpha(0.01, 0.0)); 
this.emitter[i].addBehaviour(new Proton.Scale(1.0, 1.0)); 
this.emitter[i].addBehaviour(new Proton.RandomDrift(
3*(Math.random()+0.5), 
3*(Math.random()+0.5), 
3*(Math.random()+0.5)
));

this.emittergroup.add(this.emitter[i]);

      
    function createSnow() {
    if(i % 2 == 0 && i % 3 != 0){
        var map = new THREE.TextureLoader().load("Images/smoke.png");}
    if(i % 3 == 0){
        var map = new THREE.TextureLoader().load("Images/white-cloud.png");} 
    else{
        var map = new THREE.TextureLoader().load("Images/white-smoke-1.png");}    
        var material = new THREE.SpriteMaterial({
            map: map,
            transparent: true,
            //depthTest: false, 	
            depthWrite: false,
            opacity: .5,
            blending:THREE.AdditiveBlending,
            color: 0xffffff
        });                                                
        return new THREE.Sprite(material);
    }

this.emitter[i].emit(); 
//add emitter 
this.proton.addEmitter(this.emitter[i]);  
this.proton.addRender(new Proton.SpriteRender(scene));

}//end for loop



//--------

//--------


var blackbodyspectrum = new THREE.TextureLoader().load("Images/blackbody_spectrum.png");

var star_uniforms = { 

texture: {type: "t", value: blackbodyspectrum},
highTemp: {type: 'f', value: 5800},
lowTemp: {type: 'f', value: 1600},
spothighTemp: {type: 'f', value:  6110},
spotlowTemp: {type: 'f', value: 500},
scale: {type: 'f', value: 0.5},
time: {type: 'f', value: 1.0}, 
sta: {type: 'f', value: 1.0},
} 


this.StarVertexShader = `

uniform float time; 
uniform float scale; 
varying vec3 vTexCoord3D; 
varying vec3 vNormal;
varying vec3 vViewPosition;

void main() { 	

vNormal = normalMatrix * normal;
vTexCoord3D = scale * ( position.xyz );
vec4 modelViewPosition = modelViewMatrix * vec4(position, 1.0);
vViewPosition = modelViewPosition.xyz;
gl_Position = projectionMatrix * modelViewPosition;
	
}`;

//---------

this.StarFragmentShader = `

uniform sampler2D texture;
varying vec3 vViewPosition;
varying vec3 vNormal;
varying vec3 vTexCoord3D; 
uniform float highTemp; 
uniform float lowTemp; 
uniform float spothighTemp; 
uniform float spotlowTemp; 
uniform float time;  
uniform float sta;

//****
//	Simplex 4D Noise 
//	by Ian McEwan, Ashima Arts 
// 
vec4 permute(vec4 x){return mod(((x*34.0)+1.0)*x, 289.0);} 
float permute(float x){return floor(mod(((x*34.0)+1.0)*x, 289.0));} 
vec4 taylorInvSqrt(vec4 r){return 1.79284291400159 - 0.85373472095314 * r;} 
float taylorInvSqrt(float r){return 1.79284291400159 - 0.85373472095314 * r;} 

vec4 grad4(float j, vec4 ip){ 
const vec4 ones = vec4(1.0, 1.0, 1.0, -1.0); 
vec4 p,s; 

p.xyz = floor( fract (vec3(j) * ip.xyz) * 7.0) * ip.z - 1.0; 
p.w = 1.5 - dot(abs(p.xyz), ones.xyz); 
s = vec4(lessThan(p, vec4(0.0))); 
p.xyz = p.xyz + (s.xyz*2.0 - 1.0) * s.www; 
return p; 
} 

float snoise(vec4 v){ 
const vec2 C = vec2( 0.138196601125010504, // (5 - sqrt(5))/20 G4 
                                      0.309016994374947451); // (sqrt(5) - 1)/4 F4 

// First corner 
vec4 i = floor(v + dot(v, C.yyyy) ); 
vec4 x0 = v - i + dot(i, C.xxxx); 

// Other corners 

// Rank sorting originally contributed by Bill Licea-Kane, AMD (formerly ATI) 
vec4 i0; 

vec3 isX = step( x0.yzw, x0.xxx ); 
vec3 isYZ = step( x0.zww, x0.yyz ); 
// i0.x = dot( isX, vec3( 1.0 ) ); 
i0.x = isX.x + isX.y + isX.z; 
i0.yzw = 1.0 - isX; 

// i0.y += dot( isYZ.xy, vec2( 1.0 ) ); 
i0.y += isYZ.x + isYZ.y; 
i0.zw += 1.0 - isYZ.xy; 

i0.z += isYZ.z; 
i0.w += 1.0 - isYZ.z; 

// i0 now contains the unique values 0,1,2,3 in each channel 
vec4 i3 = clamp( i0, 0.0, 1.0 ); 
vec4 i2 = clamp( i0-1.0, 0.0, 1.0 ); 
vec4 i1 = clamp( i0-2.0, 0.0, 1.0 ); 

// x0 = x0 - 0.0 + 0.0 * C 
vec4 x1 = x0 - i1 + 1.0 * C.xxxx; 
vec4 x2 = x0 - i2 + 2.0 * C.xxxx; 
vec4 x3 = x0 - i3 + 3.0 * C.xxxx; 
vec4 x4 = x0 - 1.0 + 4.0 * C.xxxx; 

// Permutations 
i = mod(i, 289.0); 
float j0 = permute( permute( permute( permute(i.w) + i.z) + i.y) + i.x); 
vec4 j1 = permute( permute( permute( permute ( 
i.w + vec4(i1.w, i2.w, i3.w, 1.0 )) 
+ i.z + vec4(i1.z, i2.z, i3.z, 1.0 )) 
+ i.y + vec4(i1.y, i2.y, i3.y, 1.0 )) 
+ i.x + vec4(i1.x, i2.x, i3.x, 1.0 )); 

// Gradients 
// ( 7*7*6 points uniformly over a cube, mapped onto a 4-octahedron.) 
// 7*7*6 = 294, which is close to the ring size 17*17 = 289. 

vec4 ip = vec4(1.0/294.0, 1.0/49.0, 1.0/7.0, 0.0) ; 

vec4 p0 = grad4(j0, ip); 
vec4 p1 = grad4(j1.x, ip); 
vec4 p2 = grad4(j1.y, ip); 
vec4 p3 = grad4(j1.z, ip); 
vec4 p4 = grad4(j1.w, ip); 

// Normalise gradients 
vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2, p2), dot(p3,p3))); 
p0 *= norm.x; 
p1 *= norm.y; p2 *= norm.z; 
p3 *= norm.w; 
p4 *= taylorInvSqrt(dot(p4,p4)); 

// Mix contributions from the five corners 
vec3 m0 = max(0.6 - vec3(dot(x0,x0), dot(x1,x1), dot(x2,x2)), 0.0); 
vec2 m1 = max(0.6 - vec2(dot(x3,x3), dot(x4,x4) ), 0.0); 
m0 = m0 * m0; 
m1 = m1 * m1; 
return 49.0 * ( dot(m0*m0, vec3( dot( p0, x0 ), dot( p1, x1 ), dot( p2, x2 ))) + dot(m1*m1, vec2( dot( p3, x3 ), dot( p4, x4 ) ) ) ) ; 
}


//****

const int octaves = 4; 
float noise(vec4 position, float frequency, float persistence ){

float total = 0.0; 
float maxAmplitude = 0.0; 
float amplitude = 1.0; 
for (int i = 0; i < octaves; i++) { 
total += snoise(position * frequency) * amplitude; // Get the noise sample 
frequency *= 2.0; // Make the wavelength twice as small 
maxAmplitude += amplitude; // Add to our maximum possible amplitude 
amplitude *= persistence; // Reduce amplitude according to persistence for the next octave 
} 
// Scale the result by the maximum amplitude 
return total / maxAmplitude; 

}

void main() { 	

vec4 position = vec4(vTexCoord3D, time);
float noiseBase = (noise(position, 0.4, 0.7) + 1.0) * 0.5;

// Sunspots 

float frequency = 0.02; 
vec4 positionspot = vec4(vTexCoord3D, time*0.5);
float t1 = snoise(positionspot * frequency)*2.5 - 2.1; 
float ss = max(0.0, t1); 
float total = noiseBase - ss*1.0;

//****

float distance = 0.95; //cheating hdr
float intensity = 0.98;
vec3 normal = normalize(vNormal);
vec3 camdir = normalize(vViewPosition);
float lambert = 1.0 - dot(normal, camdir * distance);

//****

float scalemin = 500.0;
float scalemax = 30000.0;

float u1 =(lowTemp - scalemin)/(scalemax - scalemin); 
float u2 =(highTemp - scalemin)/(scalemax - scalemin); 
float v1 =(spotlowTemp - scalemin)/(scalemax - scalemin); 
float v2 =(spothighTemp - scalemin)/(scalemax - scalemin); 

/*
gl_FragColor = ((1.0-total)*texture2D(texture, vec2(u1, 0)) 
                          + texture2D(texture, vec2(u2, 0))*total )
                          * lambert* intensity; 
  */
//------  
  
const float gamma = 1.00; 
float exposure = 1.0;

vec4 color = vec4( ((1.0-total)*texture2D(texture, vec2(u1, 0)) 
                          + texture2D(texture, vec2(u2, 0))*total )
                          * lambert* intensity );
/*                          
vec3 rgb = vec3(color.r, color.g, color.b);                         
*/

vec3 hdrColor = color.rgb; // exposure tone mapping 
float filter = 0.7;
//vec3 rgb = vec3(mapped.r*filter, mapped.g*filter, mapped.b*filter);

vec3 mapped = vec3(1.0) - exp(-hdrColor * exposure); // gamma correction 
mapped = pow(hdrColor, vec3(1.0 / gamma)); 
gl_FragColor = vec4(mapped, 1.0);
 
//------  

}`;


//----------







var halo_uniforms = { 
stretch: {type: 'f', value: 1.0},
time: {type: 'f', value: 1.0},
sta: {type: 'f', value: 1.0},
radius: {type: 'f', value: 1.0},
} 

this.StarHaloVertexShader = `
varying vec3 sPos;
uniform float sta;
uniform float stretch;
uniform float radius;
void main() {

float rotation = 0.0; 
float factor = 0.9994;
sPos = position; 
vec3 scale;

scale.x = 1.0/cos(asin(radius/sta))*factor;
scale.y = 1.0/cos(asin(radius/sta))*factor;
scale.z = 1.0/cos(asin(radius/sta))*factor;


vec3 alignedPosition = vec3(position.x * scale.x, position.y * scale.y, 0.0);

vec3 rotatedPosition;
rotatedPosition.x = cos(rotation) * alignedPosition.x - sin(rotation) * alignedPosition.y;
rotatedPosition.y = sin(rotation) * alignedPosition.x + cos(rotation) * alignedPosition.y;
rotatedPosition.z = alignedPosition.z;

vec4 finalPosition;

finalPosition = modelViewMatrix * vec4( 0, 0, 0, 1.0 );
finalPosition.xyz += rotatedPosition;
finalPosition = projectionMatrix * finalPosition;



gl_Position = finalPosition;

}`;


this.StarHaloFragmentShader = `
		
varying vec3 sPos;
uniform float radius;
void main() {

vec3 nDistVec = normalize(sPos); 
float dist = pow(sPos.x, 2.0) + pow(sPos.y, 2.0) + pow(sPos.z, 2.0); 
float scaleDist = dist; 
float magnitude = 1.0/dist * pow(radius, 2.0);
float total = magnitude;

float alpha;

if(dist <= radius*radius){
alpha = 0.0;
}
else alpha = 0.9;

gl_FragColor = vec4(vec3(1.0, 1.0, 0.9), alpha) * total; 

}`;

//--------

//uniforms: { viewVector: { type: "v3", value: camera.position } },

this.StarGlowVertexShader = `
//uniform vec3 viewVector;
varying float intensity;

void main() { 
vec3 viewVector = vec3(5000.0, 0.0, 0.0);
gl_Position = projectionMatrix * viewMatrix * modelMatrix * vec4( position, 1.0 ); 
vec3 actual_normal = vec3(modelMatrix * vec4(normal, 0.0)); 
intensity = pow( dot(normalize(viewVector), actual_normal), 6.0 );
}`;


this.StarGlowFragmentShader = `
varying float intensity;
void main() {	vec3 glow = vec3(1, 1, 0.9) * intensity; 
gl_FragColor = vec4( glow, 1.0 );
}`;


//--------


/*



*/






this.StarShader = new THREE.ShaderMaterial( {					
  uniforms: star_uniforms,					
  vertexShader: this.StarVertexShader,
  fragmentShader: this.StarFragmentShader,
  transparent: false,
}); 

this.StarHaloShader = new THREE.ShaderMaterial( {					
  uniforms: halo_uniforms,					
  vertexShader: this.StarHaloVertexShader,
  fragmentShader: this.StarHaloFragmentShader, 
  blending:THREE.AdditiveBlending,
  depthTest: false, 	
  depthWrite: false,
  transparent: true,
	polygonOffset: true, 			
	polygonOffsetFactor: 1, 			
	polygonOffsetUnits: 100,  
}); 

this.StarGlowShader = new THREE.ShaderMaterial( {					
  uniforms: star_uniforms,					
  vertexShader: this.StarGlowVertexShader,
  fragmentShader: this.StarGlowFragmentShader,
  transparent: true,
  side: THREE.BackSide, 
  blending: THREE.AdditiveBlending, 
}); 





var lensflaret = new THREE.TextureLoader().load("Images/star_glow.png");
this.lensflaremat = new THREE.MeshBasicMaterial({					
map: lensflaret,
alphaMap: lensflaret,
transparent: true,
blending:THREE.AdditiveBlending,
//alpha: 10
color: 0xffffff,
//opacity: 0.99,
depthTest: false, 	
depthWrite: false,
//side: THREE.DoubleSide
	polygonOffset: true, 			
	polygonOffsetFactor: -1, 			
	polygonOffsetUnits: 100,  
}); 





this.star = new THREE.SphereBufferGeometry(radius, 128, 128);
this.starmesh = new THREE.Mesh(this.star, this.StarShader);

this.starglow = new THREE.SphereBufferGeometry(radius*1.3, 128, 128);
this.starglowmesh = new THREE.Mesh(this.starglow, this.StarGlowShader);

this.halo = new THREE.PlaneBufferGeometry(10000, 10000, 2);
this.halomesh = new THREE.Mesh(this.halo, this.StarHaloShader);
this.halomesh.frustumCulled = false;

this.lensflare = new THREE.PlaneBufferGeometry( 10000, 10000, 2 );
this.lensflaremesh = new THREE.Mesh( this.lensflare, this.lensflaremat ); 
this.lensflaremesh.frustumCulled = false;
this.lensflaremesh.position.set(-20, 0, 0);


this.filter = new THREE.PlaneBufferGeometry( 10000, 10000, 2 );
this.filtermesh = new THREE.Mesh( this.filter, this.filtermat);
this.filtermesh.position.set(0, 0, 2000);





//-------

var texturearray = [];
var texture1 = new THREE.TextureLoader().load("Images/space_ft.png");
var texture2 = new THREE.TextureLoader().load("Images/space_bk.png");
var texture3 = new THREE.TextureLoader().load("Images/space_up.png");
var texture4 = new THREE.TextureLoader().load("Images/space_dn.png");
var texture5 = new THREE.TextureLoader().load("Images/space_rt.png");
var texture6 = new THREE.TextureLoader().load("Images/space_lf.png");


texturearray.push(new THREE.MeshBasicMaterial({ lightMap: texture1, lightMapIntensity: 3}));
texturearray.push(new THREE.MeshBasicMaterial({ lightMap: texture2, lightMapIntensity: 3}));
texturearray.push(new THREE.MeshBasicMaterial({ lightMap: texture3, lightMapIntensity: 3}));
texturearray.push(new THREE.MeshBasicMaterial({ lightMap: texture4, lightMapIntensity: 3}));
texturearray.push(new THREE.MeshBasicMaterial({ lightMap: texture5, lightMapIntensity: 3}));
texturearray.push(new THREE.MeshBasicMaterial({ lightMap: texture6, lightMapIntensity: 3}));





for(var i = 0; i < 6; i++) {
texturearray[i].side = THREE.BackSide;
}


var skyBoxGeo = new THREE.BoxGeometry(100000000, 100000000, 100000000);
skyBoxGeo.faceVertexUvs[ 1 ] = skyBoxGeo.faceVertexUvs[ 0 ];
var skymesh = new THREE.Mesh(skyBoxGeo, texturearray);
scene.add(skymesh);

//-------

//-------



this.group = new THREE.Group();
this.group.add(this.starmesh);
this.group.add(this.halomesh);
//this.group.add(this.starglowmesh);

scene.add(this.group);

scene.add(this.lensflaremesh);

}


GlowSize(stardiameter, startemperature, diameter, distance) {

var a = new THREE.Vector3().subVectors(this.position, distance);
var d = a.length();

var D = diameter * stardiameter*2;
var L = Math.pow(D, 2) * Math.pow(startemperature, 4); // Stefan Boltzmann law-factor
var size = 0.016 * Math.pow(L, 0.25) / Math.pow(d, 0.5);
this.lensflaremesh.scale.set(size, size, size);

}


blackholeupdate(dt){
this.update();

this.group.position.copy(this.position);
this.group.rotation.y -= 0.001;
this.StarShader.uniforms.time.value += dt;


//this.CoronaShader.uniforms.time.value += 0.5*dt;
this.lensflaremesh.quaternion.copy(camera.quaternion);
this.lensflaremesh.position.copy(camera.quaternion);


var di = new THREE.Vector3();
var da = new THREE.Vector3();
di = camera.position;
da = this.group.position;
var dest = this.group.position.distanceTo(di);
this.StarHaloShader.uniforms.sta.value = dest;
this.StarHaloShader.uniforms.radius.value = radius;
//document.getElementById("starx").value = dest;
//this.StarHaloShader.uniforms.stretch.value = document.getElementById("stary").value;
this.StarShader.uniforms.sta.value = dest;
this.lensflaremesh.material.opacity = dest/30000;


var vel;

for(var i = 0; i < counts; i++){  

phi = 2*Math.random()*Math.PI;
theta = -Math.PI/2 + Math.random()*Math.PI;

this.proton.emitters[i].p.x = 350*Math.cos(theta)*Math.cos(phi) + this.position.x  ;
this.proton.emitters[i].p.y = 350*Math.cos(theta)*Math.sin(phi)  + this.position.x   ;
this.proton.emitters[i].p.z = 350*Math.sin(theta)  + this.position.z    ;

vel = Math.random()*40+130;

this.proton.emitters[i].v.x = vel*Math.cos(theta)*Math.cos(phi);
this.proton.emitters[i].v.y = vel*Math.cos(theta)*Math.sin(phi);
this.proton.emitters[i].v.z = vel*Math.sin(theta);

for(var j = this.emitter[i].particles.length-1; j >=0; j--){  

var testarray = [];
testarray = Object.keys(this.emitter[i].particles[j] );
document.getElementById("starz").value = testarray;
}

} 


this.proton.update();

}//end blackholeupdate


eat(M) { // M is the other mass

   var newMass = this.mass + M.mass;

   var newPosition = new THREE.Vector3((
   this.position.multiplyScalar(this.mass) + M.position.multiplyScalar(M.mass))/newMass);
   var newVelocity = new THREE.Vector3((
   this.velocity.multiplyScalar(this.mass) + M.velocity.multiplyScalar(M.mass))/newMass);

   this.position = newPosition;
   this.velocity = newVelocity;
   this.mass = newMass;

M.kill();
        
}

kill() {
   this.exists = false;
   scene.remove(this.mesh);
   
}


}//end blackhole class




