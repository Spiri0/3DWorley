(function (root, factory) { 
     if (typeof define === 'function' && define.amd) { 
         define([], factory); 
     } else if (typeof exports === 'object') { 
         module.exports = factory(); 
     } else { 
         root.ParticleEngine = factory(); 
     } 
}(this, function () { 

    ParticleEngine.EMITTER_ADDED = 'emitterAdded';
    ParticleEngine.EMITTER_REMOVED = 'emitterRemoved';

    function ParticleEngine() {
 
        this.emitters = [];
        
    }


    ParticleEngine.prototype = {
    
   
        addEmitter: function(emitter) {
            this.emitters.push(emitter);
            emitter.parent = this;
            this.dispatchEvent("EMITTER_ADDED", emitter);
        },

        removeEmitter: function(emitter) {
            if (emitter.parent != this) return;

            this.emitters.splice(this.emitters.indexOf(emitter), 1);
            emitter.parent = null;
            this.dispatchEvent("EMITTER_REMOVED", emitter);
        },
/*
        update: function($delta) {
            this.dispatchEvent("PROTON_UPDATE", this);

            var delta = $delta || 0.0167;
            if (delta > 0) {
                var i = this.emitters.length;
                while (i--) this.emitters[i].update(delta);
            }

            this.dispatchEvent("PROTON_UPDATE_AFTER", this);
        },

        destroy: function() {
            var i = 0,
                length = this.emitters.length;

            for (i; i < length; i++) {
                this.emitters[i].destroy();
                delete this.emitters[i];
            }

            this.emitters.length = 0;
            this.pool.destroy();
        }
        
        */
      
    };



return ParticleEngine;
}));