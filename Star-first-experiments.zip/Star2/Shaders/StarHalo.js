StarHaloVertexShader = `

uniform vec3 scale;
varying vec3 sPos;
varying vec2 vUv;

void main() {

sPos = position;
vUv = uv;
float rotation = 0.0;

vec3 alignedPosition = vec3(position.x * scale.x, position.y * scale.y, position.z * scale.z);
vec2 pos = alignedPosition.xy;

vec2 rotatedPosition;
rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;

vec4 finalPosition;

finalPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
finalPosition.xy += rotatedPosition;
finalPosition = projectionMatrix * finalPosition;

gl_Position = finalPosition;
}`;


StarHaloFragmentShader = `
		
varying vec3 sPos;
varying vec2 vUv;

void main() {

vec3 nDistVec = normalize(sPos); 
float dist = pow(sPos.x, 2.0) + pow(sPos.y, 2.0); 
float scaleDist = dist; 
float magnitude = 1.0/(dist*dist) * pow(300.0, 4.0) * 0.92;
float total = magnitude;

gl_FragColor = vec4(vec3(1.0, 1.0, 0.8), 1.0) * total; 
}`;