import {main} from "./main"; 
main();